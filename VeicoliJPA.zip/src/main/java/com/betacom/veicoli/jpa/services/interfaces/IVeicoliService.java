package com.betacom.veicoli.jpa.services.interfaces;

import java.util.List;

import com.betacom.veicoli.jpa.dto.input.VeicoliReq;
import com.betacom.veicoli.jpa.dto.output.VeicoliDTO;
import com.betacom.veicoli.jpa.models.Veicoli;

public interface IVeicoliService {
	Veicoli create(VeicoliReq req) throws Exception;
	void update(Integer id, VeicoliReq req) throws Exception;
	void delete(Integer id) throws Exception;

	List<VeicoliDTO> list() throws Exception;
}
