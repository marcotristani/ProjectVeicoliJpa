package com.betacom.veicoli.jpa.services.implementations;

import org.springframework.stereotype.Service;

import com.betacom.veicoli.jpa.dto.input.TargaReq;
import com.betacom.veicoli.jpa.exceptions.AcademyException;
import com.betacom.veicoli.jpa.models.Targa;
import com.betacom.veicoli.jpa.repositories.ITargaRepository;
import com.betacom.veicoli.jpa.services.interfaces.ITargaService;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TargaImpl implements ITargaService{

	private final ITargaRepository targaRepository;
	
	@Transactional
	@Override
	public Targa create(TargaReq req) throws Exception {
		if(targaRepository.existsByTarga(req.getTarga().trim().toLowerCase()))
				throw new AcademyException("targa-fnd");
		Targa targa = new Targa();
		targa.setTarga(req.getTarga().trim().toLowerCase());
		return targaRepository.save(targa);
	}

	@Transactional
	@Override
	public Targa update(TargaReq req) throws Exception {
		Targa targa = targaRepository.findById(req.getId())
		        .orElseThrow(() -> new AcademyException("targa-ntfnd"));
		String nuova = req.getTarga().trim().toLowerCase();
		if (!nuova.equals(targa.getTarga()) && targaRepository.existsByTarga(nuova))
			throw new AcademyException("targa-fnd");
		targa.setTarga(nuova);
		return targa;
	}

	@Override
	public void delete(Integer id) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
